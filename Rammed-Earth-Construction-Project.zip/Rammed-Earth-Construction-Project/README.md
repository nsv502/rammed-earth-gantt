# Rammed Earth Construction GANTT Chart

A specialized project management tool for rammed earth construction projects, featuring:

- Interactive timeline visualization (June 20 - September 30, 2025)
- Color-coded construction phases
- Task dependency management
- Progress tracking
- Team collaboration features

## Deployment

This app is designed to run on Railway with PostgreSQL database.

### Environment Variables Required:
- `DATABASE_URL` - PostgreSQL connection string
- `NODE_ENV` - Set to "production"

### Build Commands:
- Build: `npm run build`
- Start: `npm start`

## Features

- **Site Preparation**: Survey, excavation, access roads
- **Foundation Work**: Layout, digging, concrete pour
- **Wall Construction**: Rammed earth wall sections
- **Finishing Work**: Roof structure, interior finishing, inspection

Built with React, Express.js, PostgreSQL, and Tailwind CSS.