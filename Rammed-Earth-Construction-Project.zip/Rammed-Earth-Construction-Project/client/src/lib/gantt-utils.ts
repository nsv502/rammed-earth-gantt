import type { Task, Phase } from '@shared/schema';
import { getDayPositionInTimeline, getTaskEndDate, PROJECT_START, PROJECT_END } from './date-utils';

export const DAY_WIDTH = 20; // pixels per day

export function getTaskBarPosition(task: Task): { left: number; width: number } {
  const startPosition = getDayPositionInTimeline(task.startDate);
  const endDate = getTaskEndDate(task.startDate, task.duration);
  const endPosition = getDayPositionInTimeline(endDate);
  
  return {
    left: startPosition * DAY_WIDTH,
    width: (endPosition - startPosition + 1) * DAY_WIDTH,
  };
}

export function getPhaseColor(phaseName: string, phases: Phase[]): string {
  const phase = phases.find(p => p.name === phaseName);
  return phase?.color || '#3B82F6';
}

export function getPhaseLabel(phaseName: string, phases: Phase[]): string {
  const phase = phases.find(p => p.name === phaseName);
  return phase?.label || phaseName;
}

export function groupTasksByPhase(tasks: Task[]): Record<string, Task[]> {
  return tasks.reduce((acc, task) => {
    if (!acc[task.phase]) {
      acc[task.phase] = [];
    }
    acc[task.phase].push(task);
    return acc;
  }, {} as Record<string, Task[]>);
}

export function calculateProjectProgress(tasks: Task[]): number {
  if (tasks.length === 0) return 0;
  
  const totalProgress = tasks.reduce((sum, task) => sum + (task.progress || 0), 0);
  return Math.round(totalProgress / tasks.length);
}

export function getCriticalPathTasks(tasks: Task[]): Task[] {
  return tasks.filter(task => task.isCriticalPath);
}

export function getTaskDependencies(task: Task, allTasks: Task[]): Task[] {
  const dependencyIds = task.dependsOnTaskIds || [];
  return allTasks.filter(t => dependencyIds.includes(t.id));
}

export function canStartTask(task: Task, allTasks: Task[]): boolean {
  const dependencies = getTaskDependencies(task, allTasks);
  return dependencies.every(dep => (dep.progress || 0) === 100);
}

export function getTaskStatus(task: Task, allTasks: Task[]): 'completed' | 'in-progress' | 'pending' | 'blocked' {
  const progress = task.progress || 0;
  if (progress === 100) return 'completed';
  if (progress > 0) return 'in-progress';
  if (!canStartTask(task, allTasks)) return 'blocked';
  return 'pending';
}

export function getTimelineWidth(): number {
  const totalDays = getDayPositionInTimeline(PROJECT_END) + 1;
  return totalDays * DAY_WIDTH;
}
