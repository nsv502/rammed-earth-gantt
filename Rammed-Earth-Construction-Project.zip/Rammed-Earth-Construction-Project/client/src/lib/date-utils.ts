import { format, addDays, differenceInDays, parseISO, startOfMonth, endOfMonth, eachDayOfInterval } from 'date-fns';

export const PROJECT_START = '2025-06-20';
export const PROJECT_END = '2025-09-30';

export function formatDate(date: string | Date): string {
  const d = typeof date === 'string' ? parseISO(date) : date;
  return format(d, 'yyyy-MM-dd');
}

export function formatDisplayDate(date: string | Date): string {
  const d = typeof date === 'string' ? parseISO(date) : date;
  return format(d, 'MMM dd, yyyy');
}

export function addDaysToDate(date: string, days: number): string {
  const d = parseISO(date);
  return formatDate(addDays(d, days));
}

export function getTaskEndDate(startDate: string, duration: number): string {
  return addDaysToDate(startDate, duration - 1);
}

export function getDaysBetween(startDate: string, endDate: string): number {
  return differenceInDays(parseISO(endDate), parseISO(startDate)) + 1;
}

export function getProjectDays(): string[] {
  const start = parseISO(PROJECT_START);
  const end = parseISO(PROJECT_END);
  return eachDayOfInterval({ start, end }).map(date => formatDate(date));
}

export function getMonthsInProject(): { month: string; days: number; startIndex: number }[] {
  const projectDays = getProjectDays();
  const months: { month: string; days: number; startIndex: number }[] = [];
  
  let currentMonth = '';
  let currentDays = 0;
  let startIndex = 0;
  
  projectDays.forEach((day, index) => {
    const date = parseISO(day);
    const monthYear = format(date, 'MMMM yyyy');
    
    if (monthYear !== currentMonth) {
      if (currentMonth) {
        months.push({ month: currentMonth, days: currentDays, startIndex });
      }
      currentMonth = monthYear;
      currentDays = 1;
      startIndex = index;
    } else {
      currentDays++;
    }
  });
  
  if (currentMonth) {
    months.push({ month: currentMonth, days: currentDays, startIndex });
  }
  
  return months;
}

export function getDayPositionInTimeline(date: string): number {
  const projectDays = getProjectDays();
  const index = projectDays.indexOf(date);
  return index >= 0 ? index : 0;
}

export function isToday(date: string): boolean {
  const today = formatDate(new Date());
  return date === today;
}
