import type { Task, Phase } from '@shared/schema';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Calendar, 
  Save, 
  Download, 
  Share,
  CloudRain,
  AlertTriangle,
} from 'lucide-react';
import { 
  calculateProjectProgress, 
  getCriticalPathTasks, 
  getPhaseLabel,
} from '@/lib/gantt-utils';
import { formatDisplayDate, PROJECT_START, PROJECT_END, getDaysBetween } from '@/lib/date-utils';
import { PhaseManagement } from './phase-management';

interface SidebarProps {
  tasks: Task[];
  phases: Phase[];
  onAddPhase: () => void;
  onEditPhase: (phase: Phase) => void;
  onDeletePhase: (phaseId: number) => void;
}

export function Sidebar({ tasks, phases, onAddPhase, onEditPhase, onDeletePhase }: SidebarProps) {
  const totalTasks = tasks.length;
  const projectProgress = calculateProjectProgress(tasks);
  const criticalTasks = getCriticalPathTasks(tasks);
  const totalDays = getDaysBetween(PROJECT_START, PROJECT_END);
  
  return (
    <aside className="w-80 bg-white border-r border-gray-200 h-screen sticky top-16 overflow-y-auto">
      <div className="p-6 space-y-6">
        {/* Project Overview */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Project Overview</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-gray-50 p-3 rounded-lg">
                <div className="text-2xl font-bold text-primary">{totalTasks}</div>
                <div className="text-sm text-gray-600">Total Tasks</div>
              </div>
              <div className="bg-gray-50 p-3 rounded-lg">
                <div className="text-2xl font-bold text-green-600">{projectProgress}%</div>
                <div className="text-sm text-gray-600">Complete</div>
              </div>
            </div>
            
            <div className="mt-4 space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-600">Duration:</span>
                <span className="font-medium">{totalDays} days</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-600">Start Date:</span>
                <span className="font-medium">{formatDisplayDate(PROJECT_START)}</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-600">End Date:</span>
                <span className="font-medium">{formatDisplayDate(PROJECT_END)}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Phase Management */}
        <PhaseManagement
          phases={phases}
          onAddPhase={onAddPhase}
          onEditPhase={onEditPhase}
          onDeletePhase={onDeletePhase}
        />

        {/* Weather Alerts */}
        <Card>
          <CardHeader>
            <CardTitle className="text-md">Weather Alerts</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
              <div className="flex items-center space-x-2">
                <CloudRain className="text-yellow-600 w-4 h-4" />
                <div>
                  <div className="text-sm font-medium text-yellow-800">Rain Expected</div>
                  <div className="text-xs text-yellow-700">July 15-17, 2025</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Critical Path */}
        <Card>
          <CardHeader>
            <CardTitle className="text-md">Critical Path</CardTitle>
          </CardHeader>
          <CardContent>
            {criticalTasks.length === 0 ? (
              <p className="text-sm text-gray-500">No critical path tasks identified</p>
            ) : (
              <div className="space-y-2">
                {criticalTasks.map((task) => (
                  <div key={task.id} className="text-sm text-red-600 bg-red-50 px-2 py-1 rounded">
                    <div className="flex items-center space-x-1">
                      <AlertTriangle className="w-3 h-3" />
                      <span>{task.name} ({task.duration} days)</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle className="text-md">Quick Actions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <Button variant="ghost" className="w-full justify-start">
                <Save className="w-4 h-4 mr-2" />
                Save Project
              </Button>
              <Button variant="ghost" className="w-full justify-start">
                <Download className="w-4 h-4 mr-2" />
                Export Timeline
              </Button>
              <Button variant="ghost" className="w-full justify-start">
                <Share className="w-4 h-4 mr-2" />
                Share Project
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </aside>
  );
}
