import { useState } from 'react';
import type { Task, Phase } from '@shared/schema';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { insertTaskSchema } from '@shared/schema';
import { z } from 'zod';

const taskFormSchema = insertTaskSchema.extend({
  startDate: z.string().min(1, 'Start date is required'),
  duration: z.number().min(1, 'Duration must be at least 1 day'),
  progress: z.number().min(0).max(100),
});

type TaskFormData = z.infer<typeof taskFormSchema>;

interface TaskDialogProps {
  task?: Task;
  allTasks: Task[];
  phases: Phase[];
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSave: (data: TaskFormData) => void;
  onDelete?: (taskId: number) => void;
}

export function TaskDialog({ task, allTasks, phases, open, onOpenChange, onSave, onDelete }: TaskDialogProps) {
  const [progress, setProgress] = useState(task?.progress || 0);
  
  const form = useForm<TaskFormData>({
    resolver: zodResolver(taskFormSchema),
    defaultValues: {
      projectId: task?.projectId || 1,
      name: task?.name || '',
      description: task?.description ?? '',
      startDate: task?.startDate || '',
      duration: task?.duration || 1,
      phase: task?.phase || 'site-prep',
      progress: task?.progress ?? 0,
      isCriticalPath: task?.isCriticalPath ?? false,
      dependsOnTaskIds: task?.dependsOnTaskIds ?? [],
    },
  });
  
  const handleSubmit = (data: TaskFormData) => {
    onSave({ ...data, progress });
    onOpenChange(false);
  };
  
  const availableDependencies = allTasks.filter(t => t.id !== task?.id);
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>{task ? 'Edit Task' : 'Add Task'}</DialogTitle>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Task Name</FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="Enter task name" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea 
                      {...field} 
                      value={field.value ?? ''} 
                      onChange={field.onChange}
                      placeholder="Enter task description" 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="startDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Start Date</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="duration"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Duration (days)</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        {...field} 
                        onChange={e => field.onChange(parseInt(e.target.value) || 1)}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <FormField
              control={form.control}
              name="phase"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Phase</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a phase" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {phases.map((phase) => (
                        <SelectItem key={phase.id} value={phase.name}>
                          {phase.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div>
              <FormLabel>Progress ({progress}%)</FormLabel>
              <Slider
                value={[progress]}
                onValueChange={(value) => setProgress(value[0])}
                max={100}
                step={5}
                className="mt-2"
              />
            </div>
            
            <FormField
              control={form.control}
              name="isCriticalPath"
              render={({ field }) => (
                <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                  <div className="space-y-0.5">
                    <FormLabel>Critical Path</FormLabel>
                    <div className="text-sm text-muted-foreground">
                      Mark this task as part of the critical path
                    </div>
                  </div>
                  <FormControl>
                    <Switch
                      checked={Boolean(field.value)}
                      onCheckedChange={field.onChange}
                    />
                  </FormControl>
                </FormItem>
              )}
            />
            
            <div className="flex justify-between">
              {task && onDelete && (
                <Button 
                  type="button" 
                  variant="destructive" 
                  onClick={() => onDelete(task.id)}
                >
                  Delete Task
                </Button>
              )}
              <div className="flex space-x-3 ml-auto">
                <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                  Cancel
                </Button>
                <Button type="submit">
                  {task ? 'Save Changes' : 'Add Task'}
                </Button>
              </div>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
