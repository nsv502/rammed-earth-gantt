import { useState } from 'react';
import type { Phase } from '@shared/schema';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { insertPhaseSchema } from '@shared/schema';
import { z } from 'zod';

const phaseFormSchema = insertPhaseSchema.extend({
  name: z.string().min(1, 'Phase name is required'),
  label: z.string().min(1, 'Phase label is required'),
  color: z.string().min(1, 'Color is required'),
  order: z.number().min(1, 'Order must be at least 1'),
});

type PhaseFormData = z.infer<typeof phaseFormSchema>;

interface PhaseDialogProps {
  phase?: Phase;
  allPhases: Phase[];
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSave: (data: PhaseFormData) => void;
  onDelete?: (phaseId: number) => void;
}

export function PhaseDialog({ phase, allPhases, open, onOpenChange, onSave, onDelete }: PhaseDialogProps) {
  const form = useForm<PhaseFormData>({
    resolver: zodResolver(phaseFormSchema),
    defaultValues: {
      projectId: phase?.projectId || 1,
      name: phase?.name || '',
      label: phase?.label || '',
      color: phase?.color || '#3B82F6',
      order: phase?.order || (allPhases.length + 1),
    },
  });
  
  const handleSubmit = (data: PhaseFormData) => {
    onSave(data);
    form.reset();
    onOpenChange(false);
  };
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>{phase ? 'Edit Phase' : 'Add Phase'}</DialogTitle>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Phase Name</FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="e.g. electrical-work" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="label"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Display Label</FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="e.g. Electrical Work" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="color"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Color</FormLabel>
                    <FormControl>
                      <div className="flex items-center space-x-2">
                        <Input type="color" {...field} className="w-12 h-10 p-1" />
                        <Input {...field} placeholder="#3B82F6" />
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="order"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Order</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        {...field} 
                        onChange={e => field.onChange(parseInt(e.target.value) || 1)}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <div className="flex justify-between">
              {phase && onDelete && (
                <Button 
                  type="button" 
                  variant="destructive" 
                  onClick={() => onDelete(phase.id)}
                >
                  Delete Phase
                </Button>
              )}
              <div className="flex space-x-3 ml-auto">
                <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                  Cancel
                </Button>
                <Button type="submit">
                  {phase ? 'Save Changes' : 'Add Phase'}
                </Button>
              </div>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}