import type { Phase } from '@shared/schema';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Edit, Trash2, Plus, GripVertical } from 'lucide-react';

interface PhaseManagementProps {
  phases: Phase[];
  onAddPhase: () => void;
  onEditPhase: (phase: Phase) => void;
  onDeletePhase: (phaseId: number) => void;
}

export function PhaseManagement({ phases, onAddPhase, onEditPhase, onDeletePhase }: PhaseManagementProps) {
  const sortedPhases = phases.sort((a, b) => a.order - b.order);

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg">Phase Management</CardTitle>
          <Button onClick={onAddPhase} size="sm">
            <Plus className="w-4 h-4 mr-1" />
            Add Phase
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {sortedPhases.length === 0 ? (
            <p className="text-sm text-gray-500 text-center py-4">
              No phases created yet. Click "Add Phase" to get started.
            </p>
          ) : (
            sortedPhases.map((phase) => (
              <div 
                key={phase.id} 
                className="flex items-center justify-between p-3 border border-gray-200 rounded-lg hover:bg-gray-50"
              >
                <div className="flex items-center space-x-3">
                  <GripVertical className="w-4 h-4 text-gray-400" />
                  <div 
                    className="w-4 h-4 rounded"
                    style={{ backgroundColor: phase.color }}
                  />
                  <div>
                    <div className="font-medium text-sm">{phase.label}</div>
                    <div className="text-xs text-gray-500">
                      {phase.name} • Order: {phase.order}
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onEditPhase(phase)}
                    className="h-8 w-8 p-0"
                  >
                    <Edit className="w-3 h-3" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onDeletePhase(phase.id)}
                    className="h-8 w-8 p-0 text-red-600 hover:text-red-700 hover:bg-red-50"
                  >
                    <Trash2 className="w-3 h-3" />
                  </Button>
                </div>
              </div>
            ))
          )}
        </div>
        
        {sortedPhases.length > 0 && (
          <div className="mt-4 pt-3 border-t border-gray-200">
            <p className="text-xs text-gray-500">
              Click the edit icon to rename phases or the trash icon to delete them.
              You can also click phase headers in the timeline to edit them.
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}