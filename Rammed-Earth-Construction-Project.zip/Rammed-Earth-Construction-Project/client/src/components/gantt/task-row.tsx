import type { Task, Phase } from '@shared/schema';
import { 
  getTaskBarPosition, 
  getPhaseColor, 
  getTaskStatus,
  DAY_WIDTH 
} from '@/lib/gantt-utils';
import { Badge } from '@/components/ui/badge';
import { AlertTriangle, CheckCircle, Clock, Ban } from 'lucide-react';

interface TaskRowProps {
  task: Task;
  allTasks: Task[];
  phases: Phase[];
  isPhaseHeader?: boolean;
  onTaskClick?: (task: Task) => void;
}

export function TaskRow({ task, allTasks, phases, isPhaseHeader = false, onTaskClick }: TaskRowProps) {
  const { left, width } = getTaskBarPosition(task);
  const phaseColor = getPhaseColor(task.phase, phases);
  const status = getTaskStatus(task, allTasks);
  
  const getStatusIcon = () => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="w-2 h-2 text-green-500" />;
      case 'in-progress':
        return <Clock className="w-2 h-2 text-blue-500" />;
      case 'blocked':
        return <Ban className="w-2 h-2 text-red-500" />;
      default:
        return <div className="w-2 h-2 bg-gray-400 rounded-full" />;
    }
  };
  
  const getStatusText = () => {
    switch (status) {
      case 'completed':
        return `${task.progress}%`;
      case 'in-progress':
        return 'In Progress';
      case 'blocked':
        return 'Blocked';
      default:
        return 'Pending';
    }
  };
  
  const getStatusColor = () => {
    switch (status) {
      case 'completed':
        return 'text-green-600';
      case 'in-progress':
        return 'text-blue-600';
      case 'blocked':
        return 'text-red-600';
      default:
        return 'text-gray-600';
    }
  };
  
  if (isPhaseHeader) {
    return (
      <div 
        className={`bg-opacity-5 cursor-pointer hover:bg-opacity-10 transition-colors`} 
        style={{ backgroundColor: phaseColor }}
        onClick={() => onTaskClick?.(task)}
      >
        <div className="flex items-center p-2">
          <div className="w-80 px-2">
            <div className="flex items-center space-x-2">
              <div className="text-gray-400 text-sm">▼</div>
              <div 
                className="w-3 h-3 rounded"
                style={{ backgroundColor: phaseColor }}
              />
              <span className="font-medium text-gray-900 hover:text-gray-700">
                {task.name}
              </span>
              <span className="text-xs text-gray-500 ml-2">
                (click to edit)
              </span>
            </div>
          </div>
          <div className="flex-1 relative h-8">
            <div 
              className="absolute top-1 h-6 rounded"
              style={{ 
                left: `${left}px`, 
                width: `${width}px`,
                backgroundColor: phaseColor,
              }}
            />
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div 
      className="flex items-center p-2 hover:bg-gray-50 cursor-pointer"
      onClick={() => onTaskClick?.(task)}
    >
      <div className="w-80 px-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <span className="text-sm text-gray-700">{task.name}</span>
            <Badge variant="secondary" className="text-xs">
              {task.duration} days
            </Badge>
            {task.isCriticalPath && (
              <AlertTriangle className="w-3 h-3 text-red-500" />
            )}
          </div>
          <div className="flex items-center space-x-1">
            {getStatusIcon()}
            <span className={`text-xs ${getStatusColor()}`}>
              {getStatusText()}
            </span>
          </div>
        </div>
      </div>
      
      <div className="flex-1 relative h-8">
        <div 
          className={`task-bar absolute top-2 h-4 ${task.isCriticalPath ? 'critical-path' : ''}`}
          style={{ 
            left: `${left}px`, 
            width: `${width}px`,
            backgroundColor: phaseColor,
          }}
        >
          <div 
            className="progress-overlay"
            style={{ width: `${task.progress}%` }}
          />
        </div>
        
        {/* Dependency arrows */}
        {(task.dependsOnTaskIds?.length || 0) > 0 && (
          <div 
            className="absolute top-3 w-0 h-0 border-l-4 border-l-gray-400 border-t-2 border-t-transparent border-b-2 border-b-transparent"
            style={{ left: `${left - 20}px` }}
          />
        )}
      </div>
    </div>
  );
}
