import { getMonthsInProject } from '@/lib/date-utils';
import { DAY_WIDTH } from '@/lib/gantt-utils';

export function TimelineHeader() {
  const months = getMonthsInProject();
  
  return (
    <div className="border-b border-gray-200 bg-gray-50">
      <div className="flex">
        {/* Task Column Header */}
        <div className="w-80 px-4 py-3 border-r border-gray-200">
          <div className="font-medium text-gray-900">Tasks</div>
        </div>
        
        {/* Date Headers */}
        <div className="flex-1 overflow-x-auto timeline-container">
          <div className="flex min-w-full">
            {months.map((month, index) => {
              const monthColors = [
                'bg-blue-50',
                'bg-green-50', 
                'bg-yellow-50',
                'bg-orange-50'
              ];
              const colorClass = monthColors[index % monthColors.length];
              
              return (
                <div
                  key={month.month}
                  className={`px-2 py-1 text-xs font-medium text-gray-600 border-r border-gray-200 ${colorClass}`}
                  style={{ width: `${month.days * DAY_WIDTH}px` }}
                >
                  {month.month}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
