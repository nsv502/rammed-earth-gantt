import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Plus, Search, ZoomIn, ZoomOut, Calendar, Settings } from 'lucide-react';
import type { Project, Task, Phase } from '@shared/schema';
import { Button } from '@/components/ui/button';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Sidebar } from '@/components/gantt/sidebar';
import { TimelineHeader } from '@/components/gantt/timeline-header';
import { TaskRow } from '@/components/gantt/task-row';
import { TaskDialog } from '@/components/gantt/task-dialog';
import { PhaseDialog } from '@/components/gantt/phase-dialog';
import { groupTasksByPhase, getTimelineWidth, DAY_WIDTH } from '@/lib/gantt-utils';
import { formatDisplayDate, PROJECT_START, PROJECT_END, getDaysBetween, getDayPositionInTimeline, formatDate } from '@/lib/date-utils';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

export default function GanttChart() {
  const [selectedTask, setSelectedTask] = useState<Task | undefined>();
  const [isTaskDialogOpen, setIsTaskDialogOpen] = useState(false);
  const [selectedPhase, setSelectedPhase] = useState<Phase | undefined>();
  const [isPhaseDialogOpen, setIsPhaseDialogOpen] = useState(false);
  const { toast } = useToast();
  
  // Fetch project data
  const { data: projects = [] } = useQuery<Project[]>({
    queryKey: ['/api/projects'],
  });
  
  const currentProject = projects[0]; // Using first project for now
  
  // Fetch tasks for the current project
  const { data: tasks = [], isLoading } = useQuery<Task[]>({
    queryKey: ['/api/projects/1/tasks'],
    enabled: !!currentProject,
  });

  // Fetch phases for the current project
  const { data: phases = [] } = useQuery<Phase[]>({
    queryKey: ['/api/projects/1/phases'],
    enabled: !!currentProject,
  });
  
  // Mutations for task operations
  const createTaskMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest('POST', '/api/projects/1/tasks', data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/projects/1/tasks'] });
      toast({ title: 'Task created successfully' });
    },
    onError: () => {
      toast({ title: 'Failed to create task', variant: 'destructive' });
    },
  });
  
  const updateTaskMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: any }) => {
      const response = await apiRequest('PUT', `/api/tasks/${id}`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/projects/1/tasks'] });
      toast({ title: 'Task updated successfully' });
    },
    onError: () => {
      toast({ title: 'Failed to update task', variant: 'destructive' });
    },
  });

  const deleteTaskMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/tasks/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/projects/1/tasks'] });
      toast({ title: 'Task deleted successfully' });
    },
    onError: () => {
      toast({ title: 'Failed to delete task', variant: 'destructive' });
    },
  });

  // Phase mutations
  const createPhaseMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest('POST', '/api/projects/1/phases', data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/projects/1/phases'] });
      toast({ title: 'Phase created successfully' });
    },
    onError: () => {
      toast({ title: 'Failed to create phase', variant: 'destructive' });
    },
  });

  const updatePhaseMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: any }) => {
      const response = await apiRequest('PUT', `/api/phases/${id}`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/projects/1/phases'] });
      toast({ title: 'Phase updated successfully' });
    },
    onError: () => {
      toast({ title: 'Failed to update phase', variant: 'destructive' });
    },
  });

  const deletePhaseMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/phases/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/projects/1/phases'] });
      toast({ title: 'Phase deleted successfully' });
    },
    onError: () => {
      toast({ title: 'Failed to delete phase', variant: 'destructive' });
    },
  });
  
  const handleTaskSave = (data: any) => {
    if (selectedTask) {
      updateTaskMutation.mutate({ id: selectedTask.id, data });
    } else {
      createTaskMutation.mutate(data);
    }
  };

  const handleTaskDelete = (taskId: number) => {
    deleteTaskMutation.mutate(taskId);
    setIsTaskDialogOpen(false);
  };

  const handlePhaseSave = (data: any) => {
    if (selectedPhase) {
      updatePhaseMutation.mutate({ id: selectedPhase.id, data });
    } else {
      createPhaseMutation.mutate(data);
    }
  };

  const handlePhaseDelete = (phaseId: number) => {
    deletePhaseMutation.mutate(phaseId);
    setIsPhaseDialogOpen(false);
  };

  const handleAddPhase = () => {
    setSelectedPhase(undefined);
    setIsPhaseDialogOpen(true);
  };

  const handlePhaseClick = (phase: Phase) => {
    setSelectedPhase(phase);
    setIsPhaseDialogOpen(true);
  };

  const handlePhaseHeaderClick = (task: Task) => {
    // Find the phase that matches this task's phase name
    const phase = phases.find(p => p.name === task.phase);
    if (phase) {
      setSelectedPhase(phase);
      setIsPhaseDialogOpen(true);
    }
  };
  
  const handleAddTask = () => {
    setSelectedTask(undefined);
    setIsTaskDialogOpen(true);
  };
  
  const handleTaskClick = (task: Task) => {
    setSelectedTask(task);
    setIsTaskDialogOpen(true);
  };
  
  const groupedTasks = groupTasksByPhase(tasks);
  const sortedPhases = phases.sort((a, b) => a.order - b.order);
  const totalDays = getDaysBetween(PROJECT_START, PROJECT_END);
  
  // Calculate today's position in the timeline
  const today = formatDate(new Date());
  const todayPosition = getDayPositionInTimeline(today);
  const todayLeftPosition = todayPosition * DAY_WIDTH;
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
          <p className="mt-2 text-gray-600">Loading project timeline...</p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-6 py-4 sticky top-0 z-50">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <Calendar className="text-white w-4 h-4" />
              </div>
              <div>
                <h1 className="text-xl font-semibold text-gray-900">
                  {currentProject?.name || 'Rammed Earth Construction'}
                </h1>
                <p className="text-sm text-gray-500">Project Timeline Manager</p>
              </div>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="hidden md:flex items-center space-x-2 text-sm text-gray-600">
              <Calendar className="text-primary w-4 h-4" />
              <span>{formatDisplayDate(PROJECT_START)} - {formatDisplayDate(PROJECT_END)}</span>
              <span className="bg-gray-100 px-2 py-1 rounded">{totalDays} days</span>
            </div>
            <Button variant="outline" onClick={handleAddPhase}>
              <Settings className="w-4 h-4 mr-2" />
              Manage Phases
            </Button>
            <Button onClick={handleAddTask}>
              <Plus className="w-4 h-4 mr-2" />
              Add Task
            </Button>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <Sidebar 
          tasks={tasks} 
          phases={phases}
          onAddPhase={handleAddPhase}
          onEditPhase={handlePhaseClick}
          onDeletePhase={(phaseId) => deletePhaseMutation.mutate(phaseId)}
        />

        {/* Main Content */}
        <main className="flex-1 p-6">
          {/* Timeline Controls */}
          <div className="bg-white rounded-lg border border-gray-200 p-4 mb-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <h2 className="text-lg font-semibold text-gray-900">Construction Timeline</h2>
                <div className="flex items-center space-x-2">
                  <Button variant="outline" size="sm">
                    <ZoomOut className="w-4 h-4 mr-1" />
                    Zoom Out
                  </Button>
                  <Button variant="outline" size="sm">
                    <ZoomIn className="w-4 h-4 mr-1" />
                    Zoom In
                  </Button>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <span className="text-sm text-gray-600">View:</span>
                <Select defaultValue="daily">
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="daily">Daily</SelectItem>
                    <SelectItem value="weekly">Weekly</SelectItem>
                    <SelectItem value="monthly">Monthly</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* GANTT Chart */}
          <div className="bg-white rounded-lg border border-gray-200 overflow-hidden relative">
            <TimelineHeader />
            
            {/* Task Rows */}
            <div className="divide-y divide-gray-200 max-h-[600px] overflow-y-auto overflow-x-auto timeline-container relative">
              {/* Today Indicator */}
              {todayPosition >= 0 && (
                <div 
                  className="absolute top-0 bottom-0 pointer-events-none z-10"
                  style={{ left: `${320 + todayLeftPosition}px` }}
                >
                  <div className="w-0.5 h-full bg-red-500 opacity-70"></div>
                  <div className="absolute -top-6 -left-6 bg-red-500 text-white text-xs px-2 py-1 rounded whitespace-nowrap">
                    Today
                  </div>
                </div>
              )}
              
              {sortedPhases.map((phase) => {
                const phaseTasks = groupedTasks[phase.name] || [];
                
                // Create a dummy task for phase header
                const phaseHeaderTask: Task = {
                  id: -1,
                  projectId: 1,
                  name: phaseTasks.length > 0 ? phase.label : `${phase.label} (Empty)`,
                  description: '',
                  startDate: phaseTasks[0]?.startDate || PROJECT_START,
                  duration: phaseTasks.reduce((sum, task) => sum + task.duration, 0),
                  phase: phase.name,
                  progress: 0,
                  isCriticalPath: false,
                  dependsOnTaskIds: [],
                  createdAt: new Date(),
                };
                
                return (
                  <div key={phase.id}>
                    <TaskRow 
                      task={phaseHeaderTask}
                      allTasks={tasks}
                      phases={phases}
                      isPhaseHeader
                      onTaskClick={handlePhaseHeaderClick}
                    />
                    {phaseTasks.map((task) => (
                      <TaskRow
                        key={task.id}
                        task={task}
                        allTasks={tasks}
                        phases={phases}
                        onTaskClick={handleTaskClick}
                      />
                    ))}
                  </div>
                );
              })}
            </div>
          </div>
        </main>
      </div>
      
      {/* Task Dialog */}
      <TaskDialog
        task={selectedTask}
        allTasks={tasks}
        phases={phases}
        open={isTaskDialogOpen}
        onOpenChange={setIsTaskDialogOpen}
        onSave={handleTaskSave}
        onDelete={handleTaskDelete}
      />
      
      {/* Phase Dialog */}
      <PhaseDialog
        phase={selectedPhase}
        allPhases={phases}
        open={isPhaseDialogOpen}
        onOpenChange={setIsPhaseDialogOpen}
        onSave={handlePhaseSave}
        onDelete={handlePhaseDelete}
      />
    </div>
  );
}
