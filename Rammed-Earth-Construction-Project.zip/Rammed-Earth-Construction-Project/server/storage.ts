import { users, projects, tasks, phases, type User, type InsertUser, type Project, type InsertProject, type Task, type InsertTask, type Phase, type InsertPhase } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getProjects(): Promise<Project[]>;
  getProject(id: number): Promise<Project | undefined>;
  createProject(project: InsertProject): Promise<Project>;
  updateProject(id: number, project: Partial<InsertProject>): Promise<Project | undefined>;
  deleteProject(id: number): Promise<boolean>;
  
  getTasks(projectId: number): Promise<Task[]>;
  getTask(id: number): Promise<Task | undefined>;
  createTask(task: InsertTask): Promise<Task>;
  updateTask(id: number, task: Partial<InsertTask>): Promise<Task | undefined>;
  deleteTask(id: number): Promise<boolean>;
  
  getPhases(projectId: number): Promise<Phase[]>;
  getPhase(id: number): Promise<Phase | undefined>;
  createPhase(phase: InsertPhase): Promise<Phase>;
  updatePhase(id: number, phase: Partial<InsertPhase>): Promise<Phase | undefined>;
  deletePhase(id: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private projects: Map<number, Project>;
  private tasks: Map<number, Task>;
  private phases: Map<number, Phase>;
  private currentUserId: number;
  private currentProjectId: number;
  private currentTaskId: number;
  private currentPhaseId: number;

  constructor() {
    this.users = new Map();
    this.projects = new Map();
    this.tasks = new Map();
    this.phases = new Map();
    this.currentUserId = 1;
    this.currentProjectId = 1;
    this.currentTaskId = 1;
    this.currentPhaseId = 1;

    // Initialize with sample rammed earth construction project
    this.initializeSampleData();
  }

  private initializeSampleData() {
    // Create sample project
    const project: Project = {
      id: 1,
      name: "Rammed Earth Construction",
      description: "Main rammed earth building project",
      startDate: "2025-06-20",
      endDate: "2025-09-30",
      createdAt: new Date(),
    };
    this.projects.set(1, project);
    this.currentProjectId = 2;

    // Create default phases
    const defaultPhases: Phase[] = [
      {
        id: 1,
        projectId: 1,
        name: "site-prep",
        label: "Site Preparation",
        color: "#F59E0B",
        order: 1,
        createdAt: new Date(),
      },
      {
        id: 2,
        projectId: 1,
        name: "foundation",
        label: "Foundation Work",
        color: "#EA580C",
        order: 2,
        createdAt: new Date(),
      },
      {
        id: 3,
        projectId: 1,
        name: "walls",
        label: "Wall Construction",
        color: "#DC2626",
        order: 3,
        createdAt: new Date(),
      },
      {
        id: 4,
        projectId: 1,
        name: "finishing",
        label: "Finishing Work",
        color: "#7C3AED",
        order: 4,
        createdAt: new Date(),
      },
    ];

    defaultPhases.forEach(phase => {
      this.phases.set(phase.id, phase);
    });
    this.currentPhaseId = 5;

    // Create sample tasks with proper phases and dependencies
    const sampleTasks: Task[] = [
      {
        id: 1,
        projectId: 1,
        name: "Site Survey & Marking",
        description: "Initial site survey and marking for construction",
        startDate: "2025-06-20",
        duration: 3,
        phase: "site-prep",
        progress: 100,
        isCriticalPath: false,
        dependsOnTaskIds: [],
        createdAt: new Date(),
      },
      {
        id: 2,
        projectId: 1,
        name: "Excavation Work",
        description: "Site excavation and preparation",
        startDate: "2025-06-23",
        duration: 5,
        phase: "site-prep",
        progress: 100,
        isCriticalPath: false,
        dependsOnTaskIds: [1],
        createdAt: new Date(),
      },
      {
        id: 3,
        projectId: 1,
        name: "Access Road Setup",
        description: "Setting up access roads for construction vehicles",
        startDate: "2025-06-28",
        duration: 6,
        phase: "site-prep",
        progress: 75,
        isCriticalPath: false,
        dependsOnTaskIds: [2],
        createdAt: new Date(),
      },
      {
        id: 4,
        projectId: 1,
        name: "Foundation Excavation",
        description: "Excavation for foundation work",
        startDate: "2025-07-04",
        duration: 4,
        phase: "foundation",
        progress: 100,
        isCriticalPath: true,
        dependsOnTaskIds: [3],
        createdAt: new Date(),
      },
      {
        id: 5,
        projectId: 1,
        name: "Concrete Pour",
        description: "Foundation concrete pouring",
        startDate: "2025-07-08",
        duration: 2,
        phase: "foundation",
        progress: 100,
        isCriticalPath: false,
        dependsOnTaskIds: [4],
        createdAt: new Date(),
      },
      {
        id: 6,
        projectId: 1,
        name: "Foundation Curing",
        description: "Foundation concrete curing period",
        startDate: "2025-07-10",
        duration: 7,
        phase: "foundation",
        progress: 60,
        isCriticalPath: true,
        dependsOnTaskIds: [5],
        createdAt: new Date(),
      },
      {
        id: 7,
        projectId: 1,
        name: "First Lift Rammed Earth",
        description: "First lift of rammed earth walls",
        startDate: "2025-07-17",
        duration: 10,
        phase: "walls",
        progress: 40,
        isCriticalPath: false,
        dependsOnTaskIds: [6],
        createdAt: new Date(),
      },
      {
        id: 8,
        projectId: 1,
        name: "Form Drying Period",
        description: "Drying period for first lift forms",
        startDate: "2025-07-27",
        duration: 14,
        phase: "walls",
        progress: 0,
        isCriticalPath: true,
        dependsOnTaskIds: [7],
        createdAt: new Date(),
      },
      {
        id: 9,
        projectId: 1,
        name: "Second Lift Rammed Earth",
        description: "Second lift of rammed earth walls",
        startDate: "2025-08-10",
        duration: 12,
        phase: "walls",
        progress: 0,
        isCriticalPath: false,
        dependsOnTaskIds: [8],
        createdAt: new Date(),
      },
      {
        id: 10,
        projectId: 1,
        name: "Surface Treatment",
        description: "Wall surface treatment and preparation",
        startDate: "2025-08-22",
        duration: 8,
        phase: "finishing",
        progress: 0,
        isCriticalPath: false,
        dependsOnTaskIds: [9],
        createdAt: new Date(),
      },
      {
        id: 11,
        projectId: 1,
        name: "Final Inspections",
        description: "Final construction inspections",
        startDate: "2025-08-30",
        duration: 5,
        phase: "finishing",
        progress: 0,
        isCriticalPath: false,
        dependsOnTaskIds: [10],
        createdAt: new Date(),
      },
      {
        id: 12,
        projectId: 1,
        name: "Project Completion",
        description: "Project handover and completion",
        startDate: "2025-09-04",
        duration: 2,
        phase: "finishing",
        progress: 0,
        isCriticalPath: false,
        dependsOnTaskIds: [11],
        createdAt: new Date(),
      },
    ];

    sampleTasks.forEach(task => {
      this.tasks.set(task.id, task);
    });
    this.currentTaskId = 13;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getProjects(): Promise<Project[]> {
    return Array.from(this.projects.values());
  }

  async getProject(id: number): Promise<Project | undefined> {
    return this.projects.get(id);
  }

  async createProject(insertProject: InsertProject): Promise<Project> {
    const id = this.currentProjectId++;
    const project: Project = { 
      id,
      name: insertProject.name,
      description: insertProject.description ?? null,
      startDate: insertProject.startDate,
      endDate: insertProject.endDate,
      createdAt: new Date(),
    };
    this.projects.set(id, project);
    return project;
  }

  async updateProject(id: number, updateProject: Partial<InsertProject>): Promise<Project | undefined> {
    const existing = this.projects.get(id);
    if (!existing) return undefined;
    
    const updated: Project = { ...existing, ...updateProject };
    this.projects.set(id, updated);
    return updated;
  }

  async deleteProject(id: number): Promise<boolean> {
    return this.projects.delete(id);
  }

  async getTasks(projectId: number): Promise<Task[]> {
    return Array.from(this.tasks.values()).filter(task => task.projectId === projectId);
  }

  async getTask(id: number): Promise<Task | undefined> {
    return this.tasks.get(id);
  }

  async createTask(insertTask: InsertTask): Promise<Task> {
    const id = this.currentTaskId++;
    const task: Task = { 
      id,
      name: insertTask.name,
      description: insertTask.description || null,
      startDate: insertTask.startDate,
      projectId: insertTask.projectId,
      duration: insertTask.duration,
      phase: insertTask.phase,
      progress: insertTask.progress || 0,
      isCriticalPath: insertTask.isCriticalPath || false,
      dependsOnTaskIds: insertTask.dependsOnTaskIds || [],
      createdAt: new Date(),
    };
    this.tasks.set(id, task);
    return task;
  }

  async updateTask(id: number, updateTask: Partial<InsertTask>): Promise<Task | undefined> {
    const existing = this.tasks.get(id);
    if (!existing) return undefined;
    
    const updated: Task = { ...existing, ...updateTask };
    this.tasks.set(id, updated);
    return updated;
  }

  async deleteTask(id: number): Promise<boolean> {
    return this.tasks.delete(id);
  }

  async getPhases(projectId: number): Promise<Phase[]> {
    return Array.from(this.phases.values())
      .filter(phase => phase.projectId === projectId)
      .sort((a, b) => a.order - b.order);
  }

  async getPhase(id: number): Promise<Phase | undefined> {
    return this.phases.get(id);
  }

  async createPhase(insertPhase: InsertPhase): Promise<Phase> {
    const id = this.currentPhaseId++;
    const phase: Phase = { 
      id,
      name: insertPhase.name,
      label: insertPhase.label,
      color: insertPhase.color,
      order: insertPhase.order,
      projectId: insertPhase.projectId,
      createdAt: new Date(),
    };
    this.phases.set(id, phase);
    return phase;
  }

  async updatePhase(id: number, updatePhase: Partial<InsertPhase>): Promise<Phase | undefined> {
    const existing = this.phases.get(id);
    if (!existing) return undefined;
    
    const updated: Phase = { ...existing, ...updatePhase };
    this.phases.set(id, updated);
    return updated;
  }

  async deletePhase(id: number): Promise<boolean> {
    return this.phases.delete(id);
  }
}

// Database storage implementation
export class DatabaseStorage implements IStorage {
  private initialized = false;

  private async initializeSampleData() {
    if (this.initialized) return;
    
    // Check if data already exists
    const existingProjects = await db.select().from(projects);
    if (existingProjects.length > 0) {
      this.initialized = true;
      return;
    }

    // Create sample project
    const [project] = await db.insert(projects).values({
      name: "Rammed Earth Construction Project",
      description: "Sustainable rammed earth building construction from June to September 2025",
      startDate: "2025-06-20",
      endDate: "2025-09-30",
    }).returning();

    // Create phases
    const phaseData = [
      { name: "site-prep", label: "Site Preparation", color: "#10B981", order: 1 },
      { name: "foundation", label: "Foundation Work", color: "#EA580C", order: 2 },
      { name: "walls", label: "Wall Construction", color: "#DC2626", order: 3 },
      { name: "finishing", label: "Finishing Work", color: "#7C3AED", order: 4 },
    ];

    await db.insert(phases).values(
      phaseData.map(phase => ({
        projectId: project.id,
        ...phase,
      }))
    );

    // Create sample tasks
    const taskData = [
      {
        name: "Site Survey & Marking",
        description: "Initial site survey and marking for construction",
        startDate: "2025-06-20",
        duration: 3,
        phase: "site-prep",
        progress: 100,
        isCriticalPath: false,
        dependsOnTaskIds: [],
      },
      {
        name: "Excavation Work",
        description: "Site excavation and preparation",
        startDate: "2025-06-23",
        duration: 5,
        phase: "site-prep",
        progress: 100,
        isCriticalPath: false,
        dependsOnTaskIds: [],
      },
      {
        name: "Access Road Setup",
        description: "Setting up access roads for construction vehicles",
        startDate: "2025-06-28",
        duration: 6,
        phase: "site-prep",
        progress: 75,
        isCriticalPath: false,
        dependsOnTaskIds: [],
      },
      {
        name: "Foundation Layout",
        description: "Marking and preparing foundation layout",
        startDate: "2025-07-04",
        duration: 4,
        phase: "foundation",
        progress: 50,
        isCriticalPath: true,
        dependsOnTaskIds: [],
      },
      {
        name: "Foundation Digging",
        description: "Digging foundation trenches to required depth",
        startDate: "2025-07-08",
        duration: 8,
        phase: "foundation",
        progress: 25,
        isCriticalPath: true,
        dependsOnTaskIds: [],
      },
      {
        name: "Concrete Foundation Pour",
        description: "Pouring and setting concrete foundation",
        startDate: "2025-07-16",
        duration: 10,
        phase: "foundation",
        progress: 0,
        isCriticalPath: true,
        dependsOnTaskIds: [],
      },
      {
        name: "Soil Mix Preparation",
        description: "Preparing soil mixture for rammed earth walls",
        startDate: "2025-07-26",
        duration: 5,
        phase: "walls",
        progress: 0,
        isCriticalPath: false,
        dependsOnTaskIds: [],
      },
      {
        name: "First Wall Section",
        description: "Building first section of rammed earth walls",
        startDate: "2025-07-31",
        duration: 12,
        phase: "walls",
        progress: 0,
        isCriticalPath: true,
        dependsOnTaskIds: [],
      },
      {
        name: "Second Wall Section",
        description: "Building second section of rammed earth walls",
        startDate: "2025-08-12",
        duration: 12,
        phase: "walls",
        progress: 0,
        isCriticalPath: true,
        dependsOnTaskIds: [],
      },
      {
        name: "Third Wall Section",
        description: "Building third section of rammed earth walls",
        startDate: "2025-08-24",
        duration: 10,
        phase: "walls",
        progress: 0,
        isCriticalPath: true,
        dependsOnTaskIds: [],
      },
      {
        name: "Roof Structure",
        description: "Installing roof structure and framing",
        startDate: "2025-09-03",
        duration: 8,
        phase: "finishing",
        progress: 0,
        isCriticalPath: true,
        dependsOnTaskIds: [],
      },
      {
        name: "Interior Finishing",
        description: "Interior plastering and finishing work",
        startDate: "2025-09-11",
        duration: 12,
        phase: "finishing",
        progress: 0,
        isCriticalPath: false,
        dependsOnTaskIds: [],
      },
      {
        name: "Final Inspection",
        description: "Final quality inspection and project completion",
        startDate: "2025-09-23",
        duration: 7,
        phase: "finishing",
        progress: 0,
        isCriticalPath: true,
        dependsOnTaskIds: [],
      },
    ];

    await db.insert(tasks).values(
      taskData.map(task => ({
        projectId: project.id,
        ...task,
      }))
    );

    this.initialized = true;
  }
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async getProjects(): Promise<Project[]> {
    await this.initializeSampleData();
    return await db.select().from(projects);
  }

  async getProject(id: number): Promise<Project | undefined> {
    const [project] = await db.select().from(projects).where(eq(projects.id, id));
    return project || undefined;
  }

  async createProject(insertProject: InsertProject): Promise<Project> {
    const [project] = await db.insert(projects).values(insertProject).returning();
    return project;
  }

  async updateProject(id: number, updateProject: Partial<InsertProject>): Promise<Project | undefined> {
    const [project] = await db
      .update(projects)
      .set(updateProject)
      .where(eq(projects.id, id))
      .returning();
    return project || undefined;
  }

  async deleteProject(id: number): Promise<boolean> {
    const result = await db.delete(projects).where(eq(projects.id, id));
    return (result.rowCount || 0) > 0;
  }

  async getTasks(projectId: number): Promise<Task[]> {
    return await db.select().from(tasks).where(eq(tasks.projectId, projectId));
  }

  async getTask(id: number): Promise<Task | undefined> {
    const [task] = await db.select().from(tasks).where(eq(tasks.id, id));
    return task || undefined;
  }

  async createTask(insertTask: InsertTask): Promise<Task> {
    const [task] = await db.insert(tasks).values(insertTask).returning();
    return task;
  }

  async updateTask(id: number, updateTask: Partial<InsertTask>): Promise<Task | undefined> {
    const [task] = await db
      .update(tasks)
      .set(updateTask)
      .where(eq(tasks.id, id))
      .returning();
    return task || undefined;
  }

  async deleteTask(id: number): Promise<boolean> {
    const result = await db.delete(tasks).where(eq(tasks.id, id));
    return (result.rowCount || 0) > 0;
  }

  async getPhases(projectId: number): Promise<Phase[]> {
    return await db.select().from(phases).where(eq(phases.projectId, projectId));
  }

  async getPhase(id: number): Promise<Phase | undefined> {
    const [phase] = await db.select().from(phases).where(eq(phases.id, id));
    return phase || undefined;
  }

  async createPhase(insertPhase: InsertPhase): Promise<Phase> {
    const [phase] = await db.insert(phases).values(insertPhase).returning();
    return phase;
  }

  async updatePhase(id: number, updatePhase: Partial<InsertPhase>): Promise<Phase | undefined> {
    const [phase] = await db
      .update(phases)
      .set(updatePhase)
      .where(eq(phases.id, id))
      .returning();
    return phase || undefined;
  }

  async deletePhase(id: number): Promise<boolean> {
    const result = await db.delete(phases).where(eq(phases.id, id));
    return (result.rowCount || 0) > 0;
  }
}

export const storage = new DatabaseStorage();
