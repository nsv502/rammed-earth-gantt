# Replit.md

## Overview

This is a full-stack web application for construction project management featuring an interactive Gantt chart for rammed earth construction projects. The system provides visual task tracking, progress monitoring, and project timeline management through a modern React frontend and Express.js backend.

## System Architecture

**Full-Stack TypeScript Application**
- **Frontend**: React with Vite bundler and ShadCN UI components
- **Backend**: Express.js REST API server
- **Database**: PostgreSQL with Drizzle ORM
- **Styling**: Tailwind CSS with custom CSS variables
- **State Management**: TanStack Query for server state
- **Routing**: Wouter for client-side routing

## Key Components

### Frontend Architecture
- **React Components**: Built with ShadCN UI component library for consistent design
- **Gantt Chart Visualization**: Custom components for project timeline display
- **Task Management**: Interactive task creation, editing, and progress tracking
- **Real-time Updates**: TanStack Query provides caching and synchronization

### Backend Architecture
- **RESTful API**: Express.js server with structured route handlers
- **Database Layer**: Drizzle ORM with PostgreSQL for data persistence
- **Memory Storage Fallback**: In-memory storage implementation for development
- **Error Handling**: Centralized error handling middleware

### Database Schema
```typescript
Projects: id, name, description, startDate, endDate, createdAt
Tasks: id, projectId, name, description, startDate, duration, phase, progress, isCriticalPath, dependsOnTaskIds, createdAt
Users: id, username, password
```

### API Structure
- `GET /api/projects` - List all projects
- `GET /api/projects/:id` - Get specific project
- `POST /api/projects` - Create new project
- `PUT /api/projects/:id` - Update project
- `DELETE /api/projects/:id` - Delete project
- Similar CRUD operations for tasks at `/api/projects/:id/tasks`

## Data Flow

1. **Client Request**: React components make API calls using TanStack Query
2. **Server Processing**: Express routes handle requests and validate data with Zod schemas
3. **Database Operations**: Drizzle ORM manages PostgreSQL interactions
4. **Response**: JSON data returned to client with proper error handling
5. **UI Updates**: React components re-render with new data via query invalidation

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL database connection
- **drizzle-orm**: Type-safe database ORM
- **@tanstack/react-query**: Server state management
- **@radix-ui**: Headless UI component primitives
- **wouter**: Lightweight React router
- **date-fns**: Date manipulation utilities

### Development Tools
- **Vite**: Fast build tool and dev server
- **TypeScript**: Type safety across the stack
- **Tailwind CSS**: Utility-first CSS framework
- **Zod**: Runtime type validation

## Deployment Strategy

**Replit Configuration**
- **Environment**: Node.js 20 with PostgreSQL 16
- **Development**: `npm run dev` runs both frontend and backend
- **Production Build**: Vite builds static assets, esbuild bundles server
- **Deployment**: Autoscale deployment target on port 80
- **Database**: PostgreSQL provisioned via Replit modules

**Build Process**
1. Frontend: Vite builds React app to `dist/public`
2. Backend: esbuild bundles Express server to `dist/index.js`
3. Production: Single Node.js process serves both static files and API

## Changelog

- June 19, 2025: Initial setup
- June 19, 2025: Added full task management capabilities (add/edit/delete tasks)
- June 19, 2025: Fixed "Today" indicator positioning to properly scroll with timeline
- June 19, 2025: Implemented color-coded construction phases for rammed earth project

## User Preferences

Preferred communication style: Simple, everyday language.